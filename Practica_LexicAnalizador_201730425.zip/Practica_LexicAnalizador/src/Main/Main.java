/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Backend.Automata;
import Fronted.Area_Write;
import Fronted.Ventana;
import Fronted.Menu;
import Fronted.PanelErrores;
import Fronted.PanelReport;

/**
 *
 * @author sago04
 */
public class Main {

    private static Menu menuUsuario = new Menu();
    private static PanelErrores panelErr = new PanelErrores();
    private static PanelReport panelReport= new PanelReport();
    private static Automata AnalisadorLexico= new Automata();
    private static Area_Write cuadroTexto = new Area_Write(AnalisadorLexico,panelErr,panelReport);
    
    public static void main(String[] args) {
        
        Ventana ventanaPrincipal =new Ventana();
        
        ventanaPrincipal.setPanelEst(panelErr);
        ventanaPrincipal.setPanelOest(menuUsuario);
        ventanaPrincipal.setPanelSur(panelReport);
        ventanaPrincipal.setPanelCen(cuadroTexto);
        
    }
    
}
