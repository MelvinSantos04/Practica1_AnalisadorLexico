/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.awt.Color;

/**
 *
 * @author sago04
 */
public class Token {
    
    private int fila;
    private int colum;
    private String Lexema;
    private String tipo;
    private String patron;
    private Color color;

    public Token(int fila, int colum, String Lexema, String tipo, String patron,  Color color) {
        this.fila = fila;
        this.colum = colum;
        this.Lexema = Lexema;
        this.tipo = tipo;
        this.patron = patron;
        this.color = color;
    }

    
    

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColum() {
        return colum;
    }

    public void setColum(int colum) {
        this.colum = colum;
    }

    public String getLexema() {
        return Lexema;
    }

    public void setLexema(String Lexema) {
        this.Lexema = Lexema;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPatron() {
        return patron;
    }

    public void setPatron(String patron) {
        this.patron = patron;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
    
    
    
}
