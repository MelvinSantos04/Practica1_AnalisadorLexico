/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Backend.Tokens;

import java.awt.Color;

/**
 *
 * @author sago04
 */
public enum Logicos {
    
    Y("and","Y"),
    O("or","O"),
    NEGACION("not","Negacion");
    
    
    private String simbolo;
    private String nombreSimbolo;
    private final String tipoToken;
    private final Color color= Color.cyan;

    private Logicos(String simbolo, String nombreSimbolo) {
        this.simbolo = simbolo;
        this.nombreSimbolo = nombreSimbolo;
        this.tipoToken = "Logicos";
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    public String getNombreSimbolo() {
        return nombreSimbolo;
    }

    public void setNombreSimbolo(String nombreSimbolo) {
        this.nombreSimbolo = nombreSimbolo;
    }

    public String getTipoToken() {
        return tipoToken;
    }

    public Color getColor() {
        return color;
    }

    
    
    
}
