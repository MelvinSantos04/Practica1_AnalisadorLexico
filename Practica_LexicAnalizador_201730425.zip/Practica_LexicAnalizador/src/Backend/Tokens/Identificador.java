/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Tokens;

import Backend.Token;
import java.awt.Color;

/**
 *
 * @author sago04
 */
public class Identificador extends Token {
    
    public Identificador(int fila, int colum, String Lexema, String patron, String accion, Color color) {
        super(fila, colum, Lexema, "ID", "((a..z)|(A..Z)|_)\n((a..z)|(A..Z)|(0..9)|_)*", Color.BLACK);
    }
    
}
