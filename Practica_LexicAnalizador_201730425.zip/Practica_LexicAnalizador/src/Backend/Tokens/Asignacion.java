/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Backend.Tokens;

import java.awt.Color;

/**
 *
 * @author sago04
 */
public enum Asignacion {
    
    ASIGNA("=","Asigna"),
    IGUALMAS("+=","Suma Y Asigna"),
    IGUALMENOS("-=","Resta Y Asigna"),
    IGUALPOR("*=","Multiplica Y Asigna"),
    IGUALDIV1("/=","Divide Y Asigna"),
    IGUALDIV2("//=", "Divide Y Asigna"),
    IGUALEXPO("**=","Eleva Y Asigna"),
    IGUALMOD("%=","Modulo Y Asigna");
    
    
    private String simbolo;
    private String nombreSimbolo;
    private final String tipoToken;
    private final Color color= Color.cyan;

    private Asignacion(String simbolo, String nombreSimbolo) {
        this.simbolo = simbolo;
        this.nombreSimbolo = nombreSimbolo;
        this.tipoToken = "Asignacion";
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    public String getNombreSimbolo() {
        return nombreSimbolo;
    }

    public void setNombreSimbolo(String nombreSimbolo) {
        this.nombreSimbolo = nombreSimbolo;
    }

    public String getTipoToken() {
        return tipoToken;
    }

    
    
    
}
