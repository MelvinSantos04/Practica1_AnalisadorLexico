/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Backend.Tokens;

import java.awt.Color;

/**
 *
 * @author sago04
 */
public enum Aritmeticos{
    
    SUMA("+","Suma"),
    RESTA("-","Menos"),
    EXPONENTE("**","Exponente"),
    DIVISION1("/","Division"),
    DIVISION2("//", "Division"),
    MODULO("%", "Modulo"),
    MULTIPLICACION("*","Multiplicacion");
    
    
    private String simbolo;
    private String nombreSimbolo;
    private final String tipoToken;
    private final Color color= Color.cyan;
            

    private Aritmeticos(String simbolo, String nombreSimbolo) {
        this.simbolo = simbolo;
        this.nombreSimbolo = nombreSimbolo;
        this.tipoToken = "Aritmeticos";
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    public String getNombreSimbolo() {
        return nombreSimbolo;
    }

    public void setNombreSimbolo(String nombreSimbolo) {
        this.nombreSimbolo = nombreSimbolo;
    }

    public String getTipoToken() {
        return tipoToken;
    }

    public Color getColor() {
        return color;
    }
    
   
    
    
}
