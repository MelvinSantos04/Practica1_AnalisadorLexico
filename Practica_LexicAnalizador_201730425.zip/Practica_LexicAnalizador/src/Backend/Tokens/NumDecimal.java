/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Tokens;

import Backend.Token;
import java.awt.Color;

/**
 *
 * @author sago04
 */
public class NumDecimal extends Token {
    
    public NumDecimal(int fila, int colum, String Lexema) {
        super(fila, colum, Lexema,"Numero Decimal" , "(0..9)+(.)(0..9)+", Color.ORANGE);
    }
    
}
