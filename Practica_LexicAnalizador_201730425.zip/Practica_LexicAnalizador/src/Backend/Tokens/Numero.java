/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Tokens;

import Backend.Token;
import java.awt.Color;

/**
 *
 * @author sago04
 */
public class Numero extends Token{
    
    public Numero(int fila, int colum, String Lexema, String accion, Color color) {
        super(fila, colum, Lexema, "Numero", "(0..9)+", Color.RED);
    }
    
}
