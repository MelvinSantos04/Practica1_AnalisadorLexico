/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Backend.Tokens;

import java.awt.Color;

/**
 *
 * @author sago04
 */
public enum PalabraClave{
    
    AND("and","And"),
    AS("as","As"),
    ASSERT("assert","Assert"),
    BREAK("break","Break"),
    CLASS("class","Class"),
    CONTINUE("continue","Continue"),
    DEF("def","Def"),
    DEL("del","Del"),
    ELIF("elif","Elif"),
    ELSE("else","Else"),
    EXCEPT("except","Except"),
    FALSE("False","False"),
    FINALLY("finally","Finally"),
    FOR("for","For"),
    FROM("from","From"),
    GLOBAL("global","Global"),
    IF("if","If"),
    IMPORT("import","Import"),
    IN("in","In"),
    IS("is","Is"),
    LAMBDA("lambda","Lambda"),
    NONE("None","None"),
    NONLOCAL("nonlocal","Nonlocal"),
    NOT("not","Not"),
    OR("or","Or"),
    PASS("pass","Pass"),
    RAISE("raise","Raise"),
    RETURN("return","Return"),
    TRUE("True","True"),
    TRY("try","Try"),
    WHILE("while","While"),
    WITH("with","With"),
    YIELD("yield","Yield");

    
    private String simbolo;
    private String nombreSimbolo;
    private final String tipoToken;
    private final Color color= Color.MAGENTA;
    
    

    private PalabraClave(String simbolo, String nombreSimbolo) {
        this.simbolo = simbolo;
        this.nombreSimbolo = nombreSimbolo;
        this.tipoToken = "Palabras Clave";
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    public String getNombreSimbolo() {
        return nombreSimbolo;
    }

    public void setNombreSimbolo(String nombreSimbolo) {
        this.nombreSimbolo = nombreSimbolo;
    }

    public String getTipoToken() {
        return tipoToken;
    }

    public Color getColor() {
        return color;
    }

    
    
    
    

    
    
    
    
    




    
}
