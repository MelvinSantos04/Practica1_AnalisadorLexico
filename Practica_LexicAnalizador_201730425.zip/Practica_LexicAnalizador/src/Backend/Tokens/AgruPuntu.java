/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Backend.Tokens;

import Backend.Token;
import java.awt.Color;

/**
 *
 * @author sago04
 */
public enum AgruPuntu {
    
    PARENTESISABIERTO("(","Parentesis Abierto"),
    PARENTESISCERRADO(")","Parentesis Cerrado"),
    LLAVEABIERTO("{","Llave Abierta"),
    LLAVECERRADO("}","Llave Cerrada"),
    CORCHETEABIERTO("(","Corchete Abierto"),
    CORCHETECERRADO(")","Corchete Cerrado"),
    COMA(",","Coma"),
    PUNTOYCOMA(";","Punto y Coma"),
    DOSPUNTOS(":","Dos Puntos");
    
    
    
    
    
    
    private String simbolo;
    private String nombreSimbolo;
    private String tipoToken;
    private final Color color= Color.GREEN;

    private AgruPuntu(String simbolo, String nombreSimbolo) {
        this.simbolo = simbolo;
        this.nombreSimbolo = nombreSimbolo;
        this.tipoToken = "otros";
    }

    

    public String getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }

    public String getNombreSimbolo() {
        return nombreSimbolo;
    }

    public void setNombreSimbolo(String nombreSimbolo) {
        this.nombreSimbolo = nombreSimbolo;
    }

    public String getTipoToken() {
        return tipoToken;
    }

    public void setTipoToken(String tipoToken) {
        this.tipoToken = tipoToken;
    }

    public Color getColor() {
        return color;
    }
    
    
    
    
    
    
    
    
}
