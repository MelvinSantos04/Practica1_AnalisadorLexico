/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import Backend.Tokens.AgruPuntu;
import Backend.Tokens.Aritmeticos;
import Backend.Tokens.Asignacion;
import Backend.Tokens.PalabraClave;
import Fronted.Area_Write;
import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author sago04
 */
public class Automata {

    private ArrayList<Token> listaTokens = new ArrayList<>();
    private ArrayList<Error> listaError = new ArrayList<>();
    private int fila = 1;
    private int columna = 0;
    private String cadenaToken="";
    private Area_Write areaText;

    public Automata() {

    }

    public void VerificarToken(String texto) {
        String[] filasTexto = texto.split("\n");

        for (int i = 0; i < filasTexto.length; i++) {
            fila = i + 1;
            if (Verificar_Comentario(filasTexto[i]) && !filasTexto[i].isBlank()) {

            } else if (!filasTexto[i].isBlank()) {

                IdentificarError(filasTexto[i]);
                char[] arrayCadenaExaminar = filasTexto[i].toCharArray();
                for (int j = 0; j < arrayCadenaExaminar.length; j++) {
                    columna = j;
                    if (arrayCadenaExaminar[j] == '\"' || arrayCadenaExaminar[j] == '\'') {
                        System.out.println("si hay una cadena con comillas");
                        IdentificarCadena(texto, j);
                        j=columna;
                    } else {
                        
                        VerificarId_PalabraClave(texto);
                    }

                }
            }

            columna = 0;

        }

    }

    private void IdentificarCadena(String texto, int j) {
        char[] arrayCadenaExaminar = texto.toCharArray();
        char tipComilla = arrayCadenaExaminar[j];
        for (int k = j; k < arrayCadenaExaminar.length; k++) {
            //j=k;
            columna=k;
            if (k < arrayCadenaExaminar.length - 1) {
                
                if (arrayCadenaExaminar[k + 1] == tipComilla) {
                    cadenaToken += arrayCadenaExaminar[k + 1];
                    listaTokens.add(new Token(fila, columna,cadenaToken,"Cadena", cadenaToken, Color.ORANGE));
                    cadenaToken="";
                    break;
                } else {
                    cadenaToken += arrayCadenaExaminar[k];
                }

            }

        }
        //return j;
    }

    private void IdentificarError(String cadenaLinea) {
        char[] arrayChar = cadenaLinea.toCharArray();

        for (int i = 0; i < arrayChar.length; i++) {
            columna = i;
            VerificarAlfabeto(arrayChar[i]);
                
            

        }

    }

    private String EliminarError(String Cadena) {
        String errores = " ";
        String palabraExaminar = "";
        for (int i = 0; i < listaError.size(); i++) {
            errores += listaError.get(i).getCaracter();
        }
        errores += "\t";
        char[] charError = errores.toCharArray();
        char[] cadenaList = Cadena.toCharArray();
        for (int i = 0; i < cadenaList.length; i++) {
            for (int j = 0; j < charError.length; j++) {
                if (cadenaList[i] != charError[j]) {
                    palabraExaminar += cadenaList[i];
                }
            }
        }
        return palabraExaminar;
    }

    private boolean Verificar_Comentario(String comentario) {
        char[] comentariocaracteres = comentario.toCharArray();

        if (comentariocaracteres.length > 0) {
            if (comentariocaracteres[0] == '#') {
                columna = comentario.length();
                AgregarToken(comentario, "Comentario", "(#)((N)+(l)+(L)+(S))*", Color.GRAY);
                System.out.println("si hay un comentario");
                return true;
            }
        }

        return false;
    }

    private boolean VerificarId_PalabraClave(String cadena) {
        PalabraClave[] arrayPalabras = PalabraClave.values();
        for (int i = 0; i < arrayPalabras.length; i++) {
            if (cadena.equals(arrayPalabras[i].getSimbolo())) {
                columna += cadena.length();
                listaTokens.add(new Token(fila, columna, cadena, arrayPalabras[i].getTipoToken(), arrayPalabras[i].getSimbolo(), arrayPalabras[i].getColor()));

                return true;
            }
        }
        return false;
    }

    private boolean VerificarSimbolo(char caracter) {
        AgruPuntu[] listAg = AgruPuntu.values();
        char[] listCaracter = {'+', '-', '*', '/', '%', '<', '>', '=', '!', '\n', '\t', ' ', '_', '\'', '"'};

        for (int i = 0; i < listAg.length; i++) {
            if (listAg[i].equals(caracter)) {
                return true;
            }
        }
        for (int i = 0; i < listCaracter.length; i++) {
            if (listCaracter[i] == caracter) {
                return true;
            }
        }
        return false;
    }

    private boolean VerificarAlfabeto(char caracter) {
        if (Character.isLetter(caracter)) {
            return true;
        } else if (Character.isDigit(caracter)) {
            return true;
        } else if (VerificarSimbolo(caracter)) {
            return true;
        }
        AgregarError(caracter);
        System.out.println("Error");
        return false;
    }

    private void AgregarError(char caracter) {
        listaError.add(new Error(caracter, fila, columna));

    }

    private void AgregarToken(String Lexema, String tipo, String patron, Color color) {
        listaTokens.add(new Token(fila, columna, Lexema, tipo, patron, color));
    }

    public ArrayList<Token> getListaTokens() {
        return listaTokens;
    }

    public void setListaTokens(ArrayList<Token> listaTokens) {
        this.listaTokens = listaTokens;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public ArrayList<Error> getListaError() {
        return listaError;
    }

    public void setListaError(ArrayList<Error> listaError) {
        this.listaError = listaError;
    }

    public String getCadenaToken() {
        return cadenaToken;
    }

    public void setCadenaToken(String cadenaToken) {
        this.cadenaToken = cadenaToken;
    }

    
}
